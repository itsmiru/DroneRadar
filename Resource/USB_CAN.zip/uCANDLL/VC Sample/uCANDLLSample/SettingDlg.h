#pragma once
#include "afxwin.h"


// CSettingDlg ��ȭ �����Դϴ�.

class CSettingDlg : public CDialog
{
	DECLARE_DYNAMIC(CSettingDlg)

public:
	CSettingDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CSettingDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_SETTINGDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CDialogEx *pParentDlg;
	void ParentPrintLog(CString source);
	afx_msg void OnBnClickedDone();
	virtual BOOL OnInitDialog();
	CComboBox m_BaudCtrl;
	//BOOL m_TerminationValue;
	CAN_BTR m_CANBTR;
	void uCANDLLFUNC_GetBaudrate(void);
	CAN_Mask m_CANMask;
	UINT8 m_CANFunction;
	void uCANDLLFUNC_SetBaudrate(void);
	BOOL m_AR;
	BOOL m_ABOR;
	CString m_Serial;
	void SetSerialString(char serial[10]);
	void uCANDLLFUNC_SetSerial(void);
};
