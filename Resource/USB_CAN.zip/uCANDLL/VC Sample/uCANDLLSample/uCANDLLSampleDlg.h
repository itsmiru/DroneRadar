
// uCANDLLSampleDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "c:\program files (x86)\microsoft visual studio 11.0\vc\atlmfc\include\afxwin.h"




// CuCANDLLSampleDlg dialog
class CuCANDLLSampleDlg : public CDialogEx
{
// Construction
public:
	CuCANDLLSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_UCANDLLSAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	/* uCANDLL Message Function */
	afx_msg LRESULT OnCANRx(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnCANError(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnCANTx(WPARAM wParam, LPARAM lParam);

public:
	/* LOG PRINT */
	void PrintLog(CString source);
	CString m_LogData;
	CEdit m_LogCtrl;

	/* CONTROL VARIABLE */
	/* (Send Function) */
	CComboBox m_FormatCtrl;
	CString m_IDValue;
	CComboBox m_DLCCtrl;
	CString m_DataValue[8];
	/* (Auto Function) */
	BOOL m_ckAuto;
	UINT m_nInterval;
	CButton m_btnSend;
	/* (Auto Function) */
	ULONGLONG m_TxCountValue;
	ULONGLONG m_RxCountValue;
	/* (Device Function) */
	CButton m_OpenCloseCtrl;
	CComboBox m_DeviceList;
	
	/* USER DEFINE FUNCTION */
	void uCANDLLFUNC_FindDevice(void);
	void SendFrame(void);

	/* MFC Message Function */
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedOpenclose();
	afx_msg void OnBnClickedFinddevice();
	afx_msg void OnBnClickedSetting();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnClose();
		
	/* STATUS VARIABLE */
	int m_Status;
	BOOL m_AutoSend;

	void uCANDLLFUNC_Close(void);
	afx_msg void OnBnClickedLogclear();
	afx_msg void OnBnClickedCountclear();
	void uCANDLLFUNC_Open(void);
	void uCANDLLFUNC_CANEnable(bool enable);
	afx_msg void OnBnClickedErrorstatus();
	CAN_Error m_Error;
	afx_msg void OnBnClickedCanenable();
	int m_CANStatus;
	CButton m_CANCtrl;
	char m_ConnectedSerial[15];
};
