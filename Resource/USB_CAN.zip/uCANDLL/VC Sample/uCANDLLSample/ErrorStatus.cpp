// ErrorStatus.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "uCANDLLSample.h"
#include "ErrorStatus.h"
#include "afxdialogex.h"


// CErrorStatus ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CErrorStatus, CDialog)

CErrorStatus::CErrorStatus(CWnd* pParent /*=NULL*/)
	: CDialog(CErrorStatus::IDD, pParent)
	, pParentDlg(NULL)
	, m_TEC(0)
	, m_REC(0)
	, m_LEC(0)
	, m_Stuff(0)
	, m_Form(0)
	, m_Ack(0)
	, m_Bit(0)
	, m_CRC(0)
	, m_Mode(_T(""))
{
	pParentDlg = (CDialogEx*)pParent;
}

CErrorStatus::CErrorStatus(CWnd* pParent, CAN_Error error)
	: CDialog(CErrorStatus::IDD, pParent)
	, pParentDlg(NULL)
	, m_TEC(0)
	, m_REC(0)
	, m_LEC(0)
	, m_Stuff(0)
	, m_Form(0)
	, m_Ack(0)
	, m_Bit(0)
	, m_CRC(0)
	, m_Mode(_T(""))
{
	pParentDlg = (CDialogEx*)pParent;
	m_error = error;

}



CErrorStatus::~CErrorStatus()
{
}

void CErrorStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TEC, m_TEC);
	DDV_MinMaxUInt(pDX, m_TEC, 0, 255);
	DDX_Text(pDX, IDC_REC, m_REC);
	DDV_MinMaxUInt(pDX, m_REC, 0, 255);
	DDX_Text(pDX, IDC_LEC, m_LEC);
	DDV_MinMaxUInt(pDX, m_LEC, 0, 6);
	DDX_Text(pDX, IDC_STUFF, m_Stuff);
	DDV_MinMaxUInt(pDX, m_Stuff, 0, 65535);
	DDX_Text(pDX, IDC_FORM, m_Form);
	DDV_MinMaxUInt(pDX, m_Form, 0, 65535);
	DDX_Text(pDX, IDC_ACK, m_Ack);
	DDV_MinMaxUInt(pDX, m_Ack, 0, 65535);
	DDX_Text(pDX, IDC_BIT, m_Bit);
	DDV_MinMaxUInt(pDX, m_Bit, 0, 65535);
	DDX_Text(pDX, IDC_CRC, m_CRC);
	DDV_MinMaxUInt(pDX, m_CRC, 0, 65535);
	DDX_Text(pDX, IDC_ERRORMODE, m_Mode);
}


BEGIN_MESSAGE_MAP(CErrorStatus, CDialog)
END_MESSAGE_MAP()


// CErrorStatus �޽��� ó�����Դϴ�.


BOOL CErrorStatus::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_TEC = m_error.TEC;
	m_REC = m_error.REC;
	m_LEC = m_error.LEC;
	
	switch(m_error.MODE){
		case 0	: m_Mode = _T("Active"); 
			break;
		case 1	: 
		case 2	: 
		case 3	: m_Mode = _T("Passive"); break;
		case 4	: m_Mode = _T("Bus Off"); break;
	}


	m_Stuff = m_error.Stuff_EC;
	m_Form = m_error.Form_EC;
	m_Ack = m_error.Ack_EC;
	m_Bit = m_error.Bit_EC;
	m_CRC = m_error.CRC_EC;
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
}
