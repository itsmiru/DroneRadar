// SettingDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "uCANDLLSample.h"
#include "SettingDlg.h"
#include "afxdialogex.h"
#include "uCANDLLSampleDlg.h"



CString char2CSting(char * inp)
{
	int len;
	CString str;
	BSTR buf;

	len = MultiByteToWideChar(CP_ACP, 0, inp, (int)strlen(inp), NULL, NULL);
	buf = SysAllocStringLen(NULL,len);
	MultiByteToWideChar(CP_ACP, 0, inp, (int)strlen(inp), buf, len);
	str.Format(_T("%s"),buf);

	return str;
}

char* CString2char(CString & str)
{
	long len = str.GetLength();
	len = len*2;
	char *szTemp = new char[len+1];
	memset(szTemp,0 ,len+1);
	USES_CONVERSION;
	strcpy(szTemp, T2A(str));

	return szTemp;
}


// CSettingDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CSettingDlg, CDialog)

CSettingDlg::CSettingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSettingDlg::IDD, pParent)
	, pParentDlg(NULL)
	, m_CANFunction(0)
	, m_AR(FALSE)
	, m_ABOR(FALSE)
	, m_Serial(_T(""))
{
	pParentDlg = (CDialogEx*)pParent;
}

CSettingDlg::~CSettingDlg()
{
}

void CSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BAUD, m_BaudCtrl);
	DDX_Check(pDX, IDC_DAR, m_AR);
	DDX_Check(pDX, IDC_ABOR, m_ABOR);
	DDX_Text(pDX, IDC_SERIAL, m_Serial);
	DDV_MaxChars(pDX, m_Serial, 10);
}


BEGIN_MESSAGE_MAP(CSettingDlg, CDialog)
	ON_BN_CLICKED(IDC_DONE, &CSettingDlg::OnBnClickedDone)
END_MESSAGE_MAP()


// CSettingDlg �޽��� ó�����Դϴ�.


void CSettingDlg::ParentPrintLog(CString source)
{
	((CuCANDLLSampleDlg*)pParentDlg)->PrintLog(source);
}



void CSettingDlg::OnBnClickedDone()
{
	UpdateData(TRUE);
	

	uCANDLLFUNC_SetSerial();
	uCANDLLFUNC_SetBaudrate();	
	CDialog::OnOK();
}


BOOL CSettingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_BaudCtrl.AddString(_T("150"));
	m_BaudCtrl.AddString(_T("100"));
	m_BaudCtrl.AddString(_T("125"));
	m_BaudCtrl.AddString(_T("250"));
	m_BaudCtrl.AddString(_T("500"));
	m_BaudCtrl.AddString(_T("1000"));

	m_BaudCtrl.SetCurSel(2);

	uCANDLLFUNC_GetBaudrate();

	
	return TRUE;  // return TRUE unless you set the focus to a control
}


void CSettingDlg::uCANDLLFUNC_GetBaudrate(void)
{
	UINT32 baudrate;
	CString tmp;
	UINT8 ret;
	bool flag=false;

	ret = uCAN_GetSetting(&m_CANBTR,&m_CANMask,&m_CANFunction);
	if(!ret){
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetSetting ]] Success"));
	}
	else{
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetSetting ]] Fail "));
		return;
	}
	
	ret  = uCAN_GetBaudrate(&baudrate, m_CANBTR);
	if(!ret){
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetBaudrate ]] Success "));
	}else{
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetBaudrate ]] Fail "));
		return;
	}
	
	for(int i=0;i<m_BaudCtrl.GetCount();i++){
		m_BaudCtrl.GetLBText(i,tmp);
		if(baudrate == _tstoi(tmp)){
			m_BaudCtrl.SetCurSel(i);
			flag = true;
			break;
		}
	}

	if(!flag){
		tmp.Format(_T("%d"),baudrate);
		m_BaudCtrl.AddString(tmp);
		m_BaudCtrl.SetCurSel(6);
	}


	m_AR = false;
	m_ABOR = false;

	if(m_CANFunction & 0x01)
		m_AR = true;
	if(m_CANFunction & 0x02)
		m_ABOR = true;
	UpdateData(FALSE);
}


void CSettingDlg::uCANDLLFUNC_SetBaudrate(void)
{
	CString tmp;
	UINT32 baud;
	UINT8 ret;
	UpdateData(TRUE);
	m_BaudCtrl.GetWindowTextW(tmp);
	baud = _tstoi(tmp);
	ret = uCAN_GetBTR(baud,&m_CANBTR);
	if(!ret){
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetBTR ]] Success"));
	}
	else{
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_GetBTR ]] Fail"));
	}
	
	m_CANFunction = 0;

	if(m_AR)
		m_CANFunction |= 0x01;
	if(m_ABOR)
		m_CANFunction |= 0x02;

	ret = uCAN_SetSetting(m_CANBTR,m_CANMask,m_CANFunction);
	if(!ret){
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_SetSetting ]] Success"));
	}
	else{
		tmp.Format(_T("ret = %d"),ret);
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_SetSetting ]] Fail"));
		ParentPrintLog(tmp);
	}

}


void CSettingDlg::SetSerialString(char serial[10])
{
	m_Serial = char2CSting(serial);
}


void CSettingDlg::uCANDLLFUNC_SetSerial(void)
{
	char *tmpChar;
	char Serial[10];
	UINT8 ret;
	CString tmp;
	tmpChar = CString2char(m_Serial);
	memcpy(Serial,tmpChar,10);
	ret = uCAN_SetSerial(Serial,10);
	if(!ret){
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_SetSerial ]] Success"));
	}
	else{
		tmp.Format(_T("ret = %d"),ret);
		ParentPrintLog(CALL_FUNC + _T("[[ uCAN_SetSerial ]] Fail"));
		ParentPrintLog(tmp);
	}

}
