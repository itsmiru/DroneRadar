
// uCANDLLSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "uCANDLLSample.h"
#include "uCANDLLSampleDlg.h"
#include "afxdialogex.h"
#include "SettingDlg.h"
#include "ErrorStatus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



UINT32 StringToID(CString str){
	unsigned char hex[8]={0,};
	UINT32 ret=0;
	int length;

	length = str.GetLength();
	if(length==0){
		ret =0;
		return ret;
	}

	for(int j=length-1, i=7;j>=0;j--,i--){		
		hex[i] = str.GetAt(j);
		if(0x30 <= hex[i] && hex[i] <= 0x39){//0~9
			hex[i] &= 0x0f;
		}
		else if(0x61 <= hex[i] && hex[i] <= 0x66){ //a~f
			hex[i] &= 0x0f;
			hex[i] += 9;
		}
		else if(0x41 <= hex[i] && hex[i] <= 0x46){ //A~F
			hex[i] &= 0x0f;
			hex[i] += 9;
		}
	}
	for(int k=0;k<4;k++){
		ret = ret << 8;
		hex[k*2] = hex[k*2]<<4;
		ret = ret | (hex[(k*2)+1] & 0x0F) | (hex[k*2] & 0xF0);
	}
	return ret;
}


unsigned char StringToHex(CString str)
{
	unsigned char hi=0, lo=0, ch=0;
	int length;

	length = str.GetLength();
	if(length==0){
		ch =0;
		return ch;
	}

	hi = str.GetAt(1);
	if(0x30 <= hi && hi <= 0x39){//0~9
		hi &= 0x0f;
	}
	else if(0x61 <= hi && hi <= 0x66){ //a~f
		hi &= 0x0f;
		hi += 9;
	}
	else if(0x41 <= hi && hi <= 0x46){ //A~F
		hi &= 0x0f;
		hi += 9;
	}
	
	lo = str.GetAt(0);
	if(0x30 <= lo && lo <= 0x39){//0~9
		hi &= 0x0f;
	}
	else if(0x61 <= lo && lo <= 0x66){ //a~f
		lo &= 0x0f;
		lo += 9;
	}
	else if(0x41 <= lo && lo <= 0x46){ //A~F
		lo &= 0x0f;
		lo += 9;
	}

	if(length == 2){
		lo = lo<<4;
		ch = (hi & 0x0F) | (lo & 0xF0);
	}else{
		ch = (lo & 0x0F);
	}
	return ch;
}


CuCANDLLSampleDlg::CuCANDLLSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CuCANDLLSampleDlg::IDD, pParent)
	, m_LogData(_T(""))
	, m_IDValue(_T(""))
	, m_Status(0)
	, m_ckAuto(FALSE)
	, m_nInterval(100)
	, m_AutoSend(FALSE)
	, m_TxCountValue(0)
	, m_RxCountValue(0)
	, m_CANStatus(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_Error.TEC = 0;
	m_Error.REC = 0;
	m_Error.LEC = 0;
	m_Error.MODE = 0;
	m_Error.Stuff_EC = 0;
	m_Error.Form_EC = 0;
	m_Error.Ack_EC = 0;
	m_Error.Bit_EC = 0;
	m_Error.CRC_EC = 0;

}

void CuCANDLLSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_LOG, m_LogData);
	DDX_Control(pDX, IDC_FORMAT, m_FormatCtrl);
	DDX_Control(pDX, IDC_DLC, m_DLCCtrl);
	DDX_Control(pDX, IDC_OPENCLOSE, m_OpenCloseCtrl);
	DDX_Text(pDX, IDC_ID, m_IDValue);
	DDV_MaxChars(pDX, m_IDValue, 8);
	DDX_Text(pDX, IDC_DATA1, m_DataValue[0]);
	DDX_Text(pDX, IDC_DATA2, m_DataValue[1]);
	DDX_Text(pDX, IDC_DATA3, m_DataValue[2]);
	DDX_Text(pDX, IDC_DATA4, m_DataValue[3]);
	DDX_Text(pDX, IDC_DATA5, m_DataValue[4]);
	DDX_Text(pDX, IDC_DATA6, m_DataValue[5]);
	DDX_Text(pDX, IDC_DATA7, m_DataValue[6]);
	DDX_Text(pDX, IDC_DATA8, m_DataValue[7]);
	DDV_MaxChars(pDX, m_DataValue[0], 2);
	DDV_MaxChars(pDX, m_DataValue[1], 2);
	DDV_MaxChars(pDX, m_DataValue[2], 2);
	DDV_MaxChars(pDX, m_DataValue[3], 2);
	DDV_MaxChars(pDX, m_DataValue[4], 2);
	DDV_MaxChars(pDX, m_DataValue[5], 2);
	DDV_MaxChars(pDX, m_DataValue[6], 2);
	DDV_MaxChars(pDX, m_DataValue[7], 2);

	DDX_Control(pDX, IDC_DEVICELIST, m_DeviceList);
	DDX_Control(pDX, IDC_LOG, m_LogCtrl);
	DDX_Check(pDX, IDC_AUTO, m_ckAuto);
	DDX_Text(pDX, IDC_TIME, m_nInterval);
	DDV_MinMaxUInt(pDX, m_nInterval, 1, 500);
	DDX_Control(pDX, IDC_SEND, m_btnSend);
	DDX_Text(pDX, IDC_TXCOUNT, m_TxCountValue);
	DDX_Text(pDX, IDC_RXCOUNT, m_RxCountValue);
	DDX_Control(pDX, IDC_CANENABLE, m_CANCtrl);
}




BEGIN_MESSAGE_MAP(CuCANDLLSampleDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SEND, &CuCANDLLSampleDlg::OnBnClickedSend)
	ON_BN_CLICKED(IDC_OPENCLOSE, &CuCANDLLSampleDlg::OnBnClickedOpenclose)
	ON_BN_CLICKED(IDC_FINDDEVICE, &CuCANDLLSampleDlg::OnBnClickedFinddevice)
	ON_BN_CLICKED(IDC_SETTING, &CuCANDLLSampleDlg::OnBnClickedSetting)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_MESSAGE(ON_CANRX, &CuCANDLLSampleDlg::OnCANRx)
	ON_MESSAGE(ON_CANERROR, &CuCANDLLSampleDlg::OnCANError)
	ON_MESSAGE(ON_CANTX, &CuCANDLLSampleDlg::OnCANTx)
	ON_BN_CLICKED(IDC_LOGCLEAR, &CuCANDLLSampleDlg::OnBnClickedLogclear)
	ON_BN_CLICKED(IDC_COUNTCLEAR, &CuCANDLLSampleDlg::OnBnClickedCountclear)
	ON_BN_CLICKED(IDC_ERRORSTATUS, &CuCANDLLSampleDlg::OnBnClickedErrorstatus)
	ON_BN_CLICKED(IDC_CANENABLE, &CuCANDLLSampleDlg::OnBnClickedCanenable)
END_MESSAGE_MAP()


// CuCANDLLSampleDlg message handlers

BOOL CuCANDLLSampleDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	CString tmp;
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	uCAN_InitNotifyHandle(this->GetSafeHwnd());

	uCANDLLFUNC_FindDevice();

	m_FormatCtrl.AddString(_T("STD DATA"));
	m_FormatCtrl.AddString(_T("STD REMOTE"));
	m_FormatCtrl.AddString(_T("EXT DATA"));
	m_FormatCtrl.AddString(_T("EXT REMOTE"));

	for(UINT8 i = 0; i<=8 ;i++){
		tmp.Format(_T("%d"),i);	
		m_DLCCtrl.AddString(tmp);
	}

	m_FormatCtrl.SetCurSel(0);
	m_DLCCtrl.SetCurSel(8);
	m_IDValue = _T("123");
	

	for(UINT8 i = 0; i <= 0xF ;){
		tmp.Format(_T("%X%X"),i,i+1);	
		m_DataValue[i/2] = tmp;
		i=i+2;
	}

	//m_nInterval = 100;

	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CuCANDLLSampleDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CuCANDLLSampleDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CuCANDLLSampleDlg::PrintLog(CString source)
{
	UpdateData(TRUE);
	int length = m_LogData.GetLength();
	source = source + _T("\r\n");
	if(length > 4000){
		m_LogData = source;
	}else{
		m_LogData.Insert(length,source);
	}
	UpdateData(FALSE);
	
	m_LogCtrl.LineScroll(m_LogCtrl.GetLineCount());
}


void CuCANDLLSampleDlg::OnBnClickedSend()
{
	UpdateData(TRUE);
	
	if(m_ckAuto){
		if(!m_AutoSend){
			m_AutoSend = TRUE;
			m_btnSend.SetWindowTextW(_T("Stop"));
			SetTimer(1,m_nInterval,NULL);
		}else{
			m_AutoSend = FALSE;
			m_btnSend.SetWindowTextW(_T("Send Frame"));
			KillTimer(1);
		}
	}else{
		SendFrame();
	}


}


void CuCANDLLSampleDlg::OnBnClickedOpenclose()
{
	if(m_Status){
		uCANDLLFUNC_Close();
		m_OpenCloseCtrl.SetWindowTextW(_T("Open"));
		m_Status = 0;
	}else{
		uCANDLLFUNC_Open();
		m_OpenCloseCtrl.SetWindowTextW(_T("Close"));
		m_Status = 1;
	}
}


void CuCANDLLSampleDlg::OnBnClickedFinddevice(){
	uCANDLLFUNC_FindDevice();
}


void CuCANDLLSampleDlg::OnBnClickedSetting()
{
	if(m_Status){
		CSettingDlg dlg(this);
		dlg.SetSerialString(m_ConnectedSerial);
		dlg.DoModal();
	}
}


void CuCANDLLSampleDlg::uCANDLLFUNC_FindDevice(void)
{
	int num;
	CString tmp;
	UINT8 ret;
	char Serial[15];


	ret = uCAN_FindDevice(&num);
	tmp.Format(CALL_FUNC + _T("[[ uCAN_FindDevice ]] MaxCount: %02d"),num);
	PrintLog(tmp);

	m_DeviceList.ResetContent();
	
	for(int i=0;i<num;i++){
		uCAN_GetSerial(i,Serial,15);
		tmp = _T("");		
		tmp = tmp + _T("uCAN HID Mode : ") + Serial + tmp;
		m_DeviceList.AddString(tmp);
	}

	m_DeviceList.SetCurSel(0);

}


void CuCANDLLSampleDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	SendFrame();
	CDialogEx::OnTimer(nIDEvent);
}


void CuCANDLLSampleDlg::SendFrame(void)
{
	CString log=NULL;
	CAN_Frame tx;

	
	switch(m_FormatCtrl.GetCurSel())
	{
	case 0: tx.Format = 0x14; break;
	case 1:	tx.Format = 0x15; break;
	case 2: tx.Format = 0x16; break;
	case 3: tx.Format = 0x17;break;
	}
	tx.ID = StringToID(m_IDValue);
	tx.DLC = m_DLCCtrl.GetCurSel();
	for(UINT8 i=0;i<tx.DLC;i++){
		tx.Data[i] = StringToHex(m_DataValue[i]);
	}
	uCAN_SendCANTxFrmae(tx);
}


void CuCANDLLSampleDlg::OnClose()
{

	KillTimer(1);
	uCAN_DeInitNotifyHandle();
	CDialogEx::OnClose();
}


afx_msg LRESULT CuCANDLLSampleDlg::OnCANRx(WPARAM wParam, LPARAM lParam)
{
	CAN_Frame* Rx;
	UINT8 Mode;
	CString log,tmp;
	
	Rx = (CAN_Frame*)wParam;
	Mode = (int)lParam;
	
	UpdateData(TRUE);
	m_RxCountValue++;
	UpdateData(FALSE);

	if(Mode != BUSY){
		log = _T("CAN Rx << ");
		switch(Rx->Format){
		case RX_STD_DATA: log += _T("STD DATA, "); break;
		case RX_STD_REMOTE: log += _T("STD DATA, "); break;
		case RX_EXT_DATA: log += _T("STD DATA, "); break;
		case RX_EXT_REMOTE: log += _T("STD DATA, "); break;
		}
		tmp.Format(_T("ID(0x%04X), "),Rx->ID);
		log += tmp;
		tmp.Format(_T("DLC(%d), DATA: "),Rx->DLC);
		log += tmp;
		for(UINT8 i=0;i<Rx->DLC;i++){	
			tmp.Format(_T("%02X"),Rx->Data[i]);
			log += tmp +_T(" ");
		}
		PrintLog(log);
	}



	return 0;
}


afx_msg LRESULT CuCANDLLSampleDlg::OnCANError(WPARAM wParam, LPARAM lParam)
{
	CAN_Error* error;
	UINT8 Mode;

	
	error = (CAN_Error*)wParam;
	Mode = (int)lParam;

	m_Error = *error;

	return 0;
}


afx_msg LRESULT CuCANDLLSampleDlg::OnCANTx(WPARAM wParam, LPARAM lParam)
{
	CAN_Frame* Rx;
	UINT8 Mode;
	CString log,tmp;
	
	Rx = (CAN_Frame*)wParam;
	Mode = (int)lParam;
	
	UpdateData(TRUE);
	m_TxCountValue++;
	UpdateData(FALSE);

	if(Mode != BUSY){
		log = _T("CAN Tx >> ");
		switch(Rx->Format){
		case TX_STD_DATA: log += _T("STD DATA, "); break;
		case TX_STD_REMOTE: log += _T("STD DATA, "); break;
		case TX_EXT_DATA: log += _T("STD DATA, "); break;
		case TX_EXT_REMOTE: log += _T("STD DATA, "); break;
		}
		tmp.Format(_T("ID(0x%04X), "),Rx->ID);
		log += tmp;
		tmp.Format(_T("DLC(%d), DATA: "),Rx->DLC);
		log += tmp;
		for(UINT8 i=0;i<Rx->DLC;i++){
			tmp.Format(_T("%02X"),Rx->Data[i]);
			log += tmp +_T(" ");
		}
		PrintLog(log);
	}
	
	return 0;
}


void CuCANDLLSampleDlg::uCANDLLFUNC_Close(void)
{
	UINT8 ret;
	ret = uCAN_Close();
	memset(m_ConnectedSerial,0,15);
	if(!ret){
		PrintLog(CALL_FUNC + _T("[[ uCAN_Close ]] Success"));
	}else{
		PrintLog(CALL_FUNC + _T("[[ uCAN_Close ]] Fail"));
	}
}


void CuCANDLLSampleDlg::OnBnClickedLogclear()
{
	m_LogData = _T("");
	UpdateData(FALSE);
}


void CuCANDLLSampleDlg::OnBnClickedCountclear()
{
	m_TxCountValue = 0;
	m_RxCountValue = 0;
	UpdateData(FALSE);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
}


void CuCANDLLSampleDlg::uCANDLLFUNC_Open(void)
{
	int num = m_DeviceList.GetCurSel();
	UINT ret = uCAN_Open(num);
	uCAN_GetSerial(num,m_ConnectedSerial,15);
	if(!ret)
		PrintLog(CALL_FUNC + _T("[[ uCAN_Open ]] Success"));
	else
		PrintLog(CALL_FUNC + _T("[[ uCAN_Open ]] Fail"));	
}


void CuCANDLLSampleDlg::uCANDLLFUNC_CANEnable(bool enable)
{
	CString log = CALL_FUNC;
	UINT8 ret = uCAN_CAN_Enable(enable);
	if(enable)
		log += _T("[[ uCAN_CAN_Enable(Enable) ]] ");
	else 
		log += _T("[[ uCAN_CAN_Enable(Disable) ]] ");
	if(!ret)
		log += _T("Succese");
	else
		log += _T("Fail");
	PrintLog(log);
}


void CuCANDLLSampleDlg::OnBnClickedErrorstatus()
{
	if(m_Status){
		CErrorStatus dlg(this,m_Error);
		dlg.DoModal();
	}
}



void CuCANDLLSampleDlg::OnBnClickedCanenable()
{
	if(m_CANStatus){
		m_CANStatus = 0;
		uCANDLLFUNC_CANEnable(false);
		m_CANCtrl.SetWindowTextW(_T("CAN Enable"));
	}else{
		m_CANStatus = 1;
		uCANDLLFUNC_CANEnable(true);
		m_CANCtrl.SetWindowTextW(_T("CAN Disable"));
	}
}
